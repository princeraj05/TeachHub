import { useCallback, useEffect, useState } from "react";
import axios from "axios";
import { FaCheck, FaCog, FaHistory, FaMoneyBillWave, FaReceipt } from "react-icons/fa";
import { startBackendPayment } from "../utils/razorpayCheckout";
import PaymentManagement from "./PaymentManagement";

const rupees = value => new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR" }).format((value || 0) / 100);
const headers = () => ({ Authorization: `Bearer ${localStorage.getItem("token")}` });

export default function PaymentCenter({ role }) {
  const api = import.meta.env.VITE_API_URL;
  const [data, setData] = useState({ recentPayments: [] }); const [payments, setPayments] = useState([]);
  const [subscription, setSubscription] = useState(null); const [settings, setSettings] = useState(null);
  const [message, setMessage] = useState(""); const [busy, setBusy] = useState(false);
  const load = useCallback(async () => { try {
    const calls = [axios.get(`${api}/api/payments/dashboard`, { headers: headers() }), axios.get(`${api}/api/payments`, { headers: headers() })];
    if (role === "admin") calls.push(axios.get(`${api}/api/admin/subscription`, { headers: headers() }));
    if (["superadmin", "admin", "teacher"].includes(role)) calls.push(axios.get(`${api}/api/payment-settings`, { headers: headers() }));
    const results = await Promise.all(calls); setData(results[0].data); setPayments(results[1].data);
    if (role === "admin") setSubscription(results[2].data); setSettings(results[role === "admin" ? 3 : 2]?.data || null);
  } catch (error) { setMessage(error.response?.data?.message || "Could not load payment data."); } }, [api, role]);
  useEffect(() => { load(); }, [load]);
  const paySubscription = async () => { setBusy(true); try { await startBackendPayment({ apiBase: api, token: localStorage.getItem("token"), createOrderEndpoint: "/api/school-subscription/create-order", customer: { name: localStorage.getItem("name") } }); setMessage("Subscription payment has been verified."); load(); } catch (error) { setMessage(error.response?.data?.message || error.message); } finally { setBusy(false); } };
  const decideOffline = async (id, action) => { const reason = action === "reject" ? window.prompt("Reason for rejection") : ""; if (action === "reject" && !reason) return; try { await axios.put(`${api}/api/payments/${id}/${action}-offline`, reason ? { reason } : {}, { headers: headers() }); setMessage(`Offline payment ${action}ed.`); load(); } catch (error) { setMessage(error.response?.data?.message || "Payment decision failed."); } };
  const changeSettings = async () => { const environment = window.prompt("Environment: test or live", settings?.environment || "test"); if (!environment) return; const onlineEnabled = window.confirm("Enable online Razorpay payments?"); const offlineEnabled = window.confirm("Enable offline payment requests?"); try { await axios.put(`${api}/api/payment-settings`, { environment, onlineEnabled, offlineEnabled }, { headers: headers() }); setMessage("Payment settings saved. Credentials remain server-only."); load(); } catch (error) { setMessage(error.response?.data?.message || "Settings update failed."); } };
  return <div className="max-w-6xl mx-auto space-y-6">
    <div className="flex flex-wrap justify-between gap-3"><div><p className="text-[10px] font-bold uppercase tracking-widest text-[#7C3AED]">Secure payment center</p><h1 className="text-2xl font-extrabold text-slate-800 dark:text-white">{role === "teacher" ? "My Payments" : role === "admin" ? "School Payments" : "Payment Dashboard"}</h1></div>{role === "superadmin" && <button onClick={changeSettings} className="rounded-xl border px-4 py-2 text-sm font-bold"><FaCog className="inline mr-2" />Payment settings</button>}</div>
    {message && <p className="rounded-xl border border-indigo-200 bg-indigo-50 p-3 text-sm text-indigo-800">{message}</p>}
    {settings && <p className="text-xs text-slate-500">Gateway: Razorpay ({settings.environment}) · Online {settings.onlineEnabled ? "enabled" : "disabled"} · Offline {settings.offlineEnabled ? "enabled" : "disabled"}</p>}
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4"><Metric icon={<FaMoneyBillWave />} label={role === "teacher" ? "Salary received" : "Total received"} value={rupees(data.totalReceived)} /><Metric icon={<FaHistory />} label="Pending payments" value={data.pendingPayments || 0} /><Metric icon={<FaReceipt />} label="Payment records" value={data.paymentCount || 0} /></div>
    {role === "admin" && subscription && <section className="rounded-2xl bg-white dark:bg-[#0B132A] border border-slate-200 dark:border-white/10 p-5 flex flex-wrap justify-between gap-4"><div><b className="text-slate-800 dark:text-white">School subscription: {subscription.billing?.status}</b><p className="text-sm text-slate-500 mt-1">Amount due: {rupees(subscription.billing?.amountDue)} · Next billing: {subscription.subscription?.nextBillingDate ? new Date(subscription.subscription.nextBillingDate).toLocaleDateString() : "Not set"}</p></div>{subscription.billing?.paymentRequired && <button disabled={busy} onClick={paySubscription} className="rounded-xl bg-[#7C3AED] px-4 py-2 text-sm font-bold text-white">Pay subscription</button>}</section>}
    <PaymentManagement role={role} apiBase={api} onChange={load} />
    <section className="rounded-2xl bg-white dark:bg-[#0B132A] border border-slate-200 dark:border-white/10 overflow-hidden"><div className="p-5 font-bold text-slate-800 dark:text-white">Payment history</div><div className="divide-y divide-slate-100 dark:divide-white/10">{payments.length ? payments.map(payment => <div className="p-4 flex flex-wrap justify-between items-center gap-3" key={payment._id}><div><p className="font-bold text-sm text-slate-800 dark:text-white">{rupees(payment.amount)} · {payment.purpose.replaceAll("_", " ")}</p><p className="text-xs text-slate-500">{new Date(payment.createdAt).toLocaleDateString()} {payment.receiptNumber ? ` · ${payment.receiptNumber}` : ""}</p></div><div className="flex gap-2 items-center"><span className="text-xs font-bold rounded-full bg-slate-100 dark:bg-white/10 px-3 py-1">{payment.status}</span>{role === "admin" && payment.status === "PendingVerification" && <><button onClick={() => decideOffline(payment._id, "approve")} className="text-xs rounded-lg bg-emerald-600 px-3 py-1.5 font-bold text-white"><FaCheck className="inline mr-1" />Approve</button><button onClick={() => decideOffline(payment._id, "reject")} className="text-xs rounded-lg border px-3 py-1.5 font-bold">Reject</button></>}</div></div>) : <p className="p-5 text-sm text-slate-500">No payment records found.</p>}</div></section>
  </div>;
}
function Metric({ icon, label, value }) { return <div className="rounded-2xl bg-white dark:bg-[#0B132A] border border-slate-200 dark:border-white/10 p-5"><div className="text-[#7C3AED]">{icon}</div><p className="mt-3 text-2xl font-extrabold text-slate-800 dark:text-white">{value}</p><p className="text-xs font-bold uppercase tracking-wide text-slate-400">{label}</p></div>; }
